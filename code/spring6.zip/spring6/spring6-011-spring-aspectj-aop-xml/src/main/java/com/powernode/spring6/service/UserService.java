package com.powernode.spring6.service;

/**
 * @author 动力节点
 * @version 1.0
 * @className UserService
 * @since 1.0
 **/
public class UserService {//目标对象
    public void logout(){ //目标方法
        System.out.println("系统正在安全退出...");
    }
}
