package com.powernode.spring6.bean;

/**
 * @author 动力节点
 * @version 1.0
 * @className Season
 * @since 1.0
 **/
public enum Season {
    SPRING, SUMMER, AUTUMN, WINTER
}
