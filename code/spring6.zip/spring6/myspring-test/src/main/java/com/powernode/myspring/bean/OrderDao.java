package com.powernode.myspring.bean;

/**
 * @author 动力节点
 * @version 1.0
 * @className OrderDao
 * @since 1.0
 **/
public class OrderDao {

    public void insert(){
        System.out.println("正在保存订单信息....");
    }
}
