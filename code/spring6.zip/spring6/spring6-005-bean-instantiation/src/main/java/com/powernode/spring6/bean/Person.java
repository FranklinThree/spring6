package com.powernode.spring6.bean;

/**
 * Bean
 * @author 动力节点
 * @version 1.0
 * @className Person
 * @since 1.0
 **/
public class Person { // 普通的Bean

    public Person() {
        System.out.println("Person的无参数构造方法执行。");
    }
}
