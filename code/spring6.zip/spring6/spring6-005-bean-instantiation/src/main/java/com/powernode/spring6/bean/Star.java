package com.powernode.spring6.bean;

/**
 * 明星类(Bean)
 * @author 动力节点
 * @version 1.0
 * @className Star
 * @since 1.0
 **/
public class Star {

    public Star() {
        System.out.println("Star的无参数构造方法执行。");
    }

}
