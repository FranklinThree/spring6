package com.powernode.spring6.bean;

import org.springframework.stereotype.Component;

/**
 * @author 动力节点
 * @version 1.0
 * @className User
 * @since 1.0
 **/
@Component(value = "userBean")
public class User {
}
