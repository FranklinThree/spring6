package com.powernode.spring6.bean;

import org.springframework.stereotype.Service;

/**
 * @author 动力节点
 * @version 1.0
 * @className OrderService
 * @since 1.0
 **/
//@Service(value = "os")
//@Service("os")
@Service // bean的名字是：orderService
public class OrderService {
}
