package com.powernode.spring6.dao;

import org.springframework.stereotype.Component;

/**
 * @author 动力节点
 * @version 1.0
 * @className OrderDao
 * @since 1.0
 **/
@Component
public class OrderDao {
}
