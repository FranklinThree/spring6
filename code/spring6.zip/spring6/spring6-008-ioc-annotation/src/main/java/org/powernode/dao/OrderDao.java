package org.powernode.dao;

/**
 * @author 动力节点
 * @version 1.0
 * @className OrderDao
 * @since 1.0
 **/
public interface OrderDao {

    void insert();

}
