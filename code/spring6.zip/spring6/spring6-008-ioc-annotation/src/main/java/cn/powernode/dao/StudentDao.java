package cn.powernode.dao;

/**
 * @author 动力节点
 * @version 1.0
 * @className StudentDao
 * @since 1.0
 **/
public interface StudentDao {

    void deleteById();

}
